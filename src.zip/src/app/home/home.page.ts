import { element } from 'protractor';
import { Router, ActivatedRoute } from "@angular/router";
import { Component, OnInit } from "@angular/core";
import { MenuAPIsService } from "../serviceANDmodel/menu-apis.service";

@Component({
  selector: "app-home",
  templateUrl: "home.page.html",
  styleUrls: ["home.page.scss"],
})
export class HomePage implements OnInit {
  allFoodItems: any;
  items: any;
  itemsList: any;
  likes = 0;
  itemName: any;
  byTitle: String = "";
  menuFilter:any=[];
  dietFilter:any='';
  isFav:false;
  dietValue: any;
  tfs:any;


  //userDetails:any=sessionStorage.getItem('signedUser'));
  constructor(public menuService: MenuAPIsService, private router: Router, private route:ActivatedRoute) {
    route.params.subscribe(val=>{
      this.menuFilter=JSON.parse(sessionStorage.getItem('menuFilter')) || [];
      this.dietFilter=JSON.parse(sessionStorage.getItem('dietFilter')) || '';
      console.log(sessionStorage.getItem('signedUser'));

      // if(this.menuFilter.length || this.dietFilter!= ''){
      //   var request={
      //     mealType:this.menuFilter,
      //     dietType:this.dietFilter,
      //     isFav:sessionStorage.getItem('isFav'),
      //    // userName:'ram@gmail.com
      //    userName:JSON.parse(sessionStorage.getItem('signedUser'))

      //     }
      //     console.log(this.userName);

      //   console.log("username",sessionStorage.getItem('signedUser'));
      //   //  console.log('request', request.userName);
      //   this.menuService.postFilters(request).subscribe((res)=>{
      //     console.log('response',res);
      //     this.itemsList = res;
      //   });
      // }
      // else{
      //   this.getAllMenuItems();
      // }
    })
  }

  ngOnInit(){
  }

  like() {
    this.likes = this.likes + 1;
  }

  getAllMenuItems() {
      this.menuService.getAllItems().subscribe((data: {}) => {
      //console.log(data);
      this.itemsList = data;
      //console.log(this.itemsList);
      this.allFoodItems = this.itemsList;
      //console.log('Check',this.allFoodItems);
      this.menuFilter=JSON.parse(sessionStorage.getItem('menuFilter'));
      this.dietFilter=JSON.parse(sessionStorage.getItem('dietFilter'));
      if(this.menuFilter!=null){
        let menuData=[];
        console.log(this.menuFilter);
        this.itemsList.forEach(element => {
         if(this.menuFilter.includes(element.mealType)){
         menuData.push(element);
         }
        });
        console.log(menuData);
        this.itemsList=menuData;
      }
     // console.log('Unique Id',this.allFoodItems[4].itemId);
    });
  }

  getItemsByTitle(title) {
    const regexp = new RegExp(this.tfs, 'i');
    this.menuService.getItembyTitle(title).subscribe((data: {}) => {
      console.log(data);
      this.itemsList = data;
      return this.itemsList.filter(x => regexp.test(x.title));
     // return  this.itemsList.filter(x => x.title.toLowerCase().includes(this.tfs.toLowerCase()))
     // return this.itemsList.filter(x => x.title.includes(this.tfs));
    });
  }

  description(item) {
    sessionStorage.setItem('SelectedItem',JSON.stringify(item));
    this.router.navigateByUrl("/item-description");
  }
  getStatus(data) {
    switch (data) {
      case 'Veg':
        return 'green';
      case 'Non veg':
        return 'red';
    }
  }
}
