import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {

  employeeList:any;
  employeeName:any;

  constructor(private router:Router,private ac:ActivatedRoute) { }

  name='Sarath';
  Emp_Id=4777;
  DOB='May 6th';

  show:boolean=false;
  day:boolean=false;
  data:any;


  ngOnInit() {
    this.ac.queryParams.subscribe( params => {

      console.log('params: ',params);
      if(params && params.special)
      {
        console.log('hello');
        this.data = JSON.parse(params.special);
        console.log(this.data)
      }
    })
  }
    // getEmployeeByName(){
    //   this.employeeName = [];
    //   this.employeeList = [];
    //   //console.log('sucess ',name);
    //   var name=this.byName;
    //   this.rest.getEmployeeByname(name,this.byId).subscribe((data: any) => {
    //     console.log(data);
    //     this.employeeName = data.data;
    //     this.employeeList  =this.employeeName;
    //     if(this.employeeList[0].name=="sita"){
    //    this.route.navigateByUrl("/c2");
    //     }
    //     else{
    //       this.route.navigateByUrl("/c3");
    //     }
    //   })
    // }




  foodPreference()
  {
    this.show = !this.show;

  }

  days()
  {
    this.day = !this.day
  }

}





