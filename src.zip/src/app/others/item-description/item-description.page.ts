import { MenuAPIsService } from './../../serviceANDmodel/menu-apis.service';
import { Component, OnInit } from '@angular/core';
import { ToastController } from '@ionic/angular';
@Component({
  selector: 'app-item-description',
  templateUrl: './item-description.page.html',
  styleUrls: ['./item-description.page.scss'],
})
export class ItemDescriptionPage implements OnInit {
  item:any;
  title: any;
  points: any;
  itemId: any;
  quantity: any;
  cartNumber = 1;
  likes:any=0;
  allCartItems:any=[];
  cartItemNumber=0;
  constructor(public toastCtrl: ToastController,public menuService: MenuAPIsService) { }



  async openToast() {
    const toast = await this.toastCtrl.create({
      message: 'Item added to cart!',
      duration: 2000,
      color: 'medium',
    });
    toast.present();
  }
  ngOnInit() {
  this.item = JSON.parse(sessionStorage.getItem('SelectedItem'));
  }

 cartItem = (this.item,this.title,this.itemId);

  getCartsList(){
    this.allCartItems=[];
    this.menuService.getCartList("20").subscribe((res)=> {                                    //get the all records from service
    this.allCartItems=res;                                                                           //assign the response to the allRecords array in service
  })
  }
   PostOrUpdateOnSubmit(){
     let data = {
       title:this.item.title,
       points:this.item.points,
       itemId:this.item.itemId,
       quantity:this.item.quantity,
       image:this.item.image,
       empId:"20"
     }
     this.menuService.addToCart(data).subscribe((res) => {                      // To insert data into database
       this.getCartsList();
       this.openToast();
       alert('succesfully Inserted');
      //  sessionStorage.setItem('cartNumber',JSON.stringify(this.cartNumber));
      //  this.cartItemNumber=JSON.parse(sessionStorage.getItem('cartNumber'));
      //  this.cartNumber=this.cartItemNumber+1;
     });
   }


// updateLikes(){
//   this.like
//   this.menuService.updateMenuList(this.like)
// }

   postLikes(){
     this.like();
     let likes = {
       likes:this.likes
     }
     this.menuService.postMenuList(likes).subscribe((res)=>{
       alert('like added');
     });
   }

like(){
    this.likes = this.likes + 1;
    sessionStorage.setItem('likes',this.likes)
}
  getStatus(data) {
    switch (data) {
      case 'Veg':
        return 'red';
      case 'Non veg':
        return 'green';
    }
  }
}
