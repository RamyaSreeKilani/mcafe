import { MenuAPIsService } from './../../serviceANDmodel/menu-apis.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';



@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  loginForm:FormGroup;

  valid:boolean = false;
  role1:any;
  data:any=[];

 byUserName : String = '';
 byPassword : String = '';
  user: any=[];

  signedUse:any;
  constructor(private router:Router,private fb: FormBuilder,private menuService:MenuAPIsService) {}
  ngOnInit(): void {
    this.loginForm = this.fb.group(
      {
        user:['',[Validators.required]],
        password:['',[Validators.required,Validators.minLength(6)]]
      }
    )
    this.getEmployeeByName();
  }
  getEmployeeByName(){
    this.user = [];
    this.menuService.getCredentials(this.byUserName,this.byPassword).subscribe((data: any) => {
  this.signedUse =  data;
      console.log(data);
      sessionStorage.setItem('signedUser',JSON.stringify(data));
      this.user = data.data;
      this.router.navigateByUrl("/home");
    });
  }
  signedUser(arg0: string, signedUser: any) {
    throw new Error("Method not implemented.");
  }

  keys()
  {
    return Object.keys(this.data);
  }
  objValue=Object.keys(this.data)[1];
  }



